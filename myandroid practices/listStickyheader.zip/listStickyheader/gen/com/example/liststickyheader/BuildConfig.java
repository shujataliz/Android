/** Automatically generated file. DO NOT MODIFY */
package com.example.liststickyheader;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}