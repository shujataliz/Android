/** Automatically generated file. DO NOT MODIFY */
package de.passsy.circularprogressbarsample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}