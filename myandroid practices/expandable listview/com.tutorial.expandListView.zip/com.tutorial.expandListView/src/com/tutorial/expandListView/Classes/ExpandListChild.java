package com.tutorial.expandListView.Classes;

public class ExpandListChild {

	private String Name;
	private String Tag;
	
	public String getName() {
		return Name;
	}
	public void setName(String Name) {
		this.Name = Name;
	}
	public String getTag() {
		return Tag;
	}
	public void setTag(String Tag) {
		this.Tag = Tag;
	}
}
