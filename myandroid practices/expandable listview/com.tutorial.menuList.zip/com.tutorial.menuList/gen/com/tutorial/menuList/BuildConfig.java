/** Automatically generated file. DO NOT MODIFY */
package com.tutorial.menuList;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}