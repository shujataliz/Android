package com.tutorial.menuList;

import java.util.ArrayList;

import com.tutorial.menuList.animations.ExpandAnimation;
import com.tutorial.menuList.animations.CollapseAnimation;
import com.tutorial.menuList.R;
import com.tutorial.expandListView.Adapter.ExpandListAdapter;
import com.tutorial.expandListView.Classes.*;

import android.app.Activity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ExpandableListView;

public class MainActivity extends Activity {
	/** Called when the activity is first created. */
	private LinearLayout MenuList;
	private Button btnToggleMenuList;
	private int screenWidth;
	private boolean isExpanded;
	private ExpandListAdapter ExpAdapter;
	private ArrayList<ExpandListGroup> ExpListItems;
	private ExpandableListView ExpandList;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		ExpandList = (ExpandableListView) findViewById(R.id.ExpList);
		ExpListItems = SetStandardGroups();
		ExpAdapter = new ExpandListAdapter(MainActivity.this,
				ExpListItems);
		ExpandList.setAdapter(ExpAdapter);
		
		MenuList = (LinearLayout) findViewById(R.id.ExpList);
		btnToggleMenuList = (Button) findViewById(R.id.button1);
		DisplayMetrics metrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(metrics);
		screenWidth = metrics.widthPixels;
		btnToggleMenuList.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if (isExpanded) {
					isExpanded = false;
					MenuList.startAnimation(new CollapseAnimation(MenuList, 0,
							(int) (screenWidth * 0.7), 20));
					
				} else {
					isExpanded = true;
					MenuList.startAnimation(new ExpandAnimation(MenuList, 0,
							(int) (screenWidth * 0.7), 20));
				}
			}
		});
	}

	public ArrayList<ExpandListGroup> SetStandardGroups() {
		ArrayList<ExpandListGroup> list = new ArrayList<ExpandListGroup>();
		ArrayList<ExpandListChild> list2 = new ArrayList<ExpandListChild>();
		ExpandListGroup gru1 = new ExpandListGroup();
		gru1.setName("Comedy");
		ExpandListChild ch1_1 = new ExpandListChild();
		ch1_1.setName("A movie");
		ch1_1.setTag(null);
		list2.add(ch1_1);
		ExpandListChild ch1_2 = new ExpandListChild();
		ch1_2.setName("An other movie");
		ch1_2.setTag(null);
		list2.add(ch1_2);
		ExpandListChild ch1_3 = new ExpandListChild();
		ch1_3.setName("And an other movie");
		ch1_3.setTag(null);
		list2.add(ch1_3);
		gru1.setItems(list2);
		list2 = new ArrayList<ExpandListChild>();

		ExpandListGroup gru2 = new ExpandListGroup();
		gru2.setName("Action");
		ExpandListChild ch2_1 = new ExpandListChild();
		ch2_1.setName("A movie");
		ch2_1.setTag(null);
		list2.add(ch2_1);
		ExpandListChild ch2_2 = new ExpandListChild();
		ch2_2.setName("An other movie");
		ch2_2.setTag(null);
		list2.add(ch2_2);
		ExpandListChild ch2_3 = new ExpandListChild();
		ch2_3.setName("And an other movie");
		ch2_3.setTag(null);
		list2.add(ch2_3);
		gru2.setItems(list2);
		list.add(gru1);
		list.add(gru2);

		return list;
	}
}