/** Automatically generated file. DO NOT MODIFY */
package sh.google.maps;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}